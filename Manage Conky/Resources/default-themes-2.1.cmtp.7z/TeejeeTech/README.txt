NVIDIA Panel requires the proprietary driver from NVIDIA.
Values will be displayed as N/A if you use the default open-source driver (noveau).

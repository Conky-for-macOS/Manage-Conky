# default-themes

*DISCLAIMER:* I **DO NOT own nor have created any of these conky Widgets / Themes except of one (npyl-process-panel) which is based on conky_seamod irc.**

The creator is usually written inside the respective Theme / Widget.

## DONATING 💰

If you want to support me for my work in [Conky-for-macOS](https://github.com/Conky-for-macOS) you can do so in the following ways: 

*DISCLAIMER: I **DO NOT** ask you reward me for the work regarding the Themes / Widgets of this Repo; They are the work of **OTHER PEOPLE** and I am **just** a distributor / packager.  **Please reward them instead!**  In case you desire to reward me for my work in the Organisation then I will be honoured and thankful to you!.* :beers:

***PayPal coming soon 👊***

```
BTC: 31qFE5JFeReEftU1sjDqigUDmpxYuTdwQm
BCH: qq04pjvvlx406r7pd9dm3ft2smc4qc2njyjccpd6kw
LTC: 3N1EuxbmeXeTFjLEqmHeZfjK7HUig9XzpX
```

***NOTE:*** ManageConky should always have the up-to-date version of the keys; Just go to **About->Press the Bitcoin icon** and you got it. <br>
Thank you. :beers:
